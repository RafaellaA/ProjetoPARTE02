#include "figurageometrica.h"
#include <iostream>

FiguraGeometrica::FiguraGeometrica()
{

}

FiguraGeometrica::~FiguraGeometrica()
{
   std::cout<< " Destrutor ";
}
