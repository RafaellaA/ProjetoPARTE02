#ifndef CUTSPHERE_H
#define CUTSPHERE_H
#include "figurageometrica.h"

class CutSphere:public FiguraGeometrica
{
public:
    CutSphere();
    void draw(Sculptor &s);
};

#endif // CUTSPHERE_H
