#include "cutbox.h"

CutBox::CutBox(int i0, int i1, int j0, int j1, int k0, int k1)
{
    x0 = i0; y0 = j0; z0 = k0;
    x1 = i1; y1 = j1; z1 = k1;

}

void CutBox::draw(Sculptor &s)
{

}
