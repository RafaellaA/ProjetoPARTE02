#include "putsphere.h"

PutSphere::PutSphere(int _nx, int _ny, int _nz, int icenter, int jcenter, int kcenter, int r)
{
    nx = _nx; ny = _ny; nz = _nz;
    xcenter = icenter; ycenter = jcenter; zcenter = kcenter; radius = r;
}

void PutSphere::draw(Sculptor &s)
{
    for(int i = 0; i<nx; i++){
            for(int j = 0; j<ny; j++){
                for(int k = 0; k<nz; k++){
                    if(((i - xcenter)*(i - xcenter) + (j - ycenter)*(j - ycenter) + (k - zcenter)*(k - zcenter)) <= radius*radius){
                        s.setColor(r,g,b,alpha);
                        s.putVoxel(xcenter,ycenter,zcenter);
                    }
                }
            }
        }
}
