#ifndef CUTVOXEL_H
#define CUTVOXEL_H
#include "figurageometrica.h"

class CutVoxel:public FiguraGeometrica
{
public:
    CutVoxel();
    void draw(Sculptor &s);
};

#endif // CUTVOXEL_H
