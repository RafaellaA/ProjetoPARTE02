#ifndef CUTELLIPSOID_H
#define CUTELLIPSOID_H
#include "figurageometrica.h"

class CutEllipsoid:public FiguraGeometrica
{
public:
    CutEllipsoid();
    void draw(Sculptor &s);
};

#endif // CUTELLIPSOID_H
