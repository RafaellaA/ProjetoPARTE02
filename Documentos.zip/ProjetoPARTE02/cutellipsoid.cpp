#include "cutellipsoid.h"


CutEllipsoid::CutEllipsoid()
{

}

void CutEllipsoid::draw(Sculptor &s)
{

}
