#include "cutsphere.h"


CutSphere::CutSphere()
{

}

void CutSphere::draw(Sculptor &s)
{

}
