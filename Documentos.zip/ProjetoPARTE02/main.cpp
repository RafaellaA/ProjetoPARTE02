#include <iostream>
#include "sculptor.h"


using namespace std;

int main(void)
{
    Sculptor s(5,5,5);
    //FiguraGeometrica *f;
    //PutBox *pbx,bx;
    //f = new PutBox(5,5,1,4,3,10);
    //f->draw(s);
    s.setColor(0,1,0,1);
    s.putVoxel(0,0,0);
    s.setColor(0,0,1,1);
    s.putVoxel(1,2,2);

    s.writeOFF("/home/rafaella/Documentos/ProjetoPARTE02/test.off");
    s.writeVECT("/home/rafaella/Documentos/ProjetoPARTE02/test.vect");
    //s.writeDIM("/home/rafaella/Documentos/ProjetoPARTE02/teste.DIM");


    return 0;
}
