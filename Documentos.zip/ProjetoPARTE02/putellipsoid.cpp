#include "putellipsoid.h"
#include <cmath>


PutEllipsoid::PutEllipsoid(int _nx,int _ny,int _nz,int icenter, int jcenter, int kcenter, int _rx, int _ry, int _rz)
{

    nx = _nx; ny = _ny; nz = _nz;
    xcenter = icenter; ycenter = jcenter; zcenter = kcenter;
    rx = _rx; ry = _ry; rz = _rz;
}

void PutEllipsoid::draw(Sculptor &s)
{
    for(int i = 0; i<nx; i++){
            for(int j = 0; j<ny; j++){
                for(int k = 0; k<nz; k++){
                    if(((pow((i - xcenter),2)/(float)pow(rx,2) + (pow((j - ycenter),2))/(float)pow(ry,2) + (pow((k - zcenter),2))/(float)pow(rz,2)) <= 1)){
                        s.setColor(r,g,b,alpha);
                        s.putVoxel(xcenter,ycenter,zcenter);
                    }
                }
            }
        }

}

