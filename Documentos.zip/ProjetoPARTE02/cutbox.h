#ifndef CUTBOX_H
#define CUTBOX_H
#include "figurageometrica.h"

class CutBox: public FiguraGeometrica
{
private:
    int x0,x1,y0,y1,z0,z1;
    float r,g,b,alpha;

public:
    CutBox(int i0,int i1,int j0, int j1,int k0, int k1);
    void draw(Sculptor &s);
};

#endif // CUTBOX_H
