#include "cutvoxel.h"


CutVoxel::CutVoxel()
{

}

void CutVoxel::draw(Sculptor &s)
{

}
