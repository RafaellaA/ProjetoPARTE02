#ifndef PUTBOX_H
#define PUTBOX_H
#include "figurageometrica.h"

class PutBox:public FiguraGeometrica
{
private:
    int x0,y0,z0,x1,y1,z1;
    float r,g,b,alpha;
public:
    PutBox(int i0,int i1,int j0,int j1,int k0,int k1);
    void draw(Sculptor &s);
};

#endif // PUTBOX_H
