#include "putbox.h"
#include <iostream>


PutBox::PutBox(int i0, int i1, int j0, int j1, int k0, int k1)
{
    x0 = i0; y0 = j0; z0 = k0;
    x1 = i1; y1 = j1; z1 = k1;
}

void PutBox::draw(Sculptor &s)
{
    s.setColor(r,g,b,alpha);
    for(int x=x0;x<x1;x++){
        for(int y=y0;y<y1;y++){
            for(int z=z0;z<z1;z++){
                s.putVoxel(x,y,z);
            }
        }
    }
}
